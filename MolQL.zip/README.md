Build

    npm install
    npm run build

Interactive builds on file save

    npm run watch

Building docs
 
    npm run docs